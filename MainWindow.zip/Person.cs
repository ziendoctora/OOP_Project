﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Project1
{
    class Person
    {
        public string FirstName;
        public string MiddleName;
        public string LastName;
        public string BirthDate;
        public string Address;

    
        public string GetFullName(string firstName, string middleName, string lastName)
        { 

             FirstName = firstName;
             MiddleName = middleName;
             LastName = lastName;

             if (Convert.ToInt32(MiddleName.Length) == 1)
             {
                return ((char.ToUpper(FirstName[0]) + FirstName.Substring(1)) + " " + char.ToUpper(MiddleName[0]) + ". " + (char.ToUpper(LastName[0]) + LastName.Substring(1)));

             }
            else
            {
                return (char.ToUpper(FirstName[0]) + FirstName.Substring(1)) + " " +
                     char.ToUpper(LastName[0]) + LastName.Substring(1);
            }
        }

        public static int GetAge(string birthDate)
        {
          return Calculations.CalculateAge(birthDate);
        }
    }
}
