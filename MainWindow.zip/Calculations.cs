﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Project1
{
    
    
    class Calculations
    {
        
        public static int CalculateAge( string birthDate, bool returnInMonths = false )
        {
           
            int age;

            DateTime now = DateTime.UtcNow;
            DateTime past = Convert.ToDateTime(birthDate);

            age = (now.Year - past.Year) + (now.Month - past.Month)/12;
            if ( returnInMonths )
                age = age * 12;
            return age;

        }
        public decimal CalculateInterest( decimal principalAmount, decimal monthlyRate )
        {
            return (principalAmount * (monthlyRate / 100));
        }
        public decimal CalculateAccruedAmount( decimal principalAmount, decimal monthlyRate, string date )
        {
            
            return principalAmount + CalculateInterest(principalAmount, monthlyRate) * CalculateAge(date, true);
            
        }
    }
}
